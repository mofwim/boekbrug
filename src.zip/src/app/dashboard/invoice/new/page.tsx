'use client'

// src/app/dashboard/invoice/new/page.tsx
// [BOEK-031] Complete rebuild — Factuur / Offerte / Credit — May 2026
// Mobile-first, iOS-style design
// Supports: autocomplete clients, AI translation, offerte→factuur conversion

import React, { useState, useEffect, useRef, Suspense } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
// [BOEK-031] Navigation Strategy — May 2026
import { useParentPath, useHomePath } from '@/lib/navigation-hooks'
import type { Role } from '@/lib/navigation'

// ─── Fixed Dutch formatting — never changes ────────────────────────────────────
const NL_NUMBER = new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' })

// ─── [BOEK-031] Invoice number generator — new format: 001-2026 — May 2026 ───
// Queries DB directly to get next sequence for this user + year
// factuur:    001-2026
// creditnota: CR-001-2026
// pro_forma:  PF-001-2026
async function generateNumber(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  type: 'factuur' | 'creditnota' | 'pro_forma'
): Promise<string> {
  const year = new Date().getFullYear()
  const prefix = type === 'creditnota' ? 'CR-' : type === 'pro_forma' ? 'PF-' : ''

  // Find highest existing sequence for this user + year + type
  const { data } = await supabase
    .from('invoices')
    .select('invoice_number')
    .eq('sender_id', userId)
    .eq('invoice_type', type)
    .ilike('invoice_number', `${prefix}%-${year}`)
    .order('created_at', { ascending: false })
    .limit(50)

  let maxSeq = 0
  for (const inv of data ?? []) {
    const num = inv.invoice_number ?? ''
    // Extract sequence: "CR-016-2026" → 16, "001-2026" → 1
    const parts = num.replace(/^(CR-|PF-)/, '').split('-')
    const seq = parseInt(parts[0], 10)
    if (!isNaN(seq) && seq > maxSeq) maxSeq = seq
  }

  const nextSeq = String(maxSeq + 1).padStart(3, '0')
  return `${prefix}${nextSeq}-${year}`
}

// ─── Types ─────────────────────────────────────────────────────────────────────

// [BOEK-031] fix type — creditnota replaces credit — May 2026
type InvoiceType = 'factuur' | 'offerte' | 'creditnota'

type Profile = {
  id: string
  full_name: string
  company_name: string
  kvk_number: string
  btw_number: string
  iban: string
  address: string
  postal_code: string
  city: string
  email: string
  // [BOEK-031] role needed for navigation parent — May 2026
  role?: string | null
}

type Client = {
  id: string
  name: string
  email: string
  address: string
  postal_code: string
  city: string
  btw_number: string
  kvk_number: string
}

type InvoiceLine = {
  description: string
  quantity: number
  unit_price: number
  btw_rate: number
  // [BOEK-031] AI translation support per line
  translating?: boolean
  rawInput?: string
}

type SentInvoice = {
  id: string
  invoice_number: string
  client_name: string
  total_inc_btw: number
}

// ─── Config ────────────────────────────────────────────────────────────────────

// [DS] Design System v1.0 — Type config with DS tokens
const TYPE_CONFIG: Record<InvoiceType, {
  label: string
  activeBg: string      // active chip background
  activeColor: string   // active chip text
  activeBorder: string  // active chip border
  primaryBtn: string    // primary button color
  focusColor: string    // input focus border color
}> = {
  factuur: {
    label: 'Factuur',
    activeBg: '#D3E3FD', activeColor: '#1967D2', activeBorder: '#1A73E8',
    primaryBtn: '#1A73E8', focusColor: '#1A73E8',
  },
  offerte: {
    label: 'Offerte',
    activeBg: '#FEF7E0', activeColor: '#EA8600', activeBorder: '#FBBC04',
    primaryBtn: '#FBBC04', focusColor: '#FBBC04',
  },
  creditnota: {
    label: 'Credit',
    activeBg: '#F9DEDC', activeColor: '#B3261E', activeBorder: '#EA4335',
    primaryBtn: '#EA4335', focusColor: '#EA4335',
  },
}

// ─── [DS] LineInput — number input for Factuurregels ─────────────────────────
// Fixes: no leading zero, comma/dot both work, step=1, Enter→next input
function LineInput({
  label, value, onChange, min = 0, focusColor, hasError = false,
}: {
  label: string
  value: number
  onChange: (v: number) => void
  min?: number
  focusColor: string
  hasError?: boolean
}) {
  const [focused, setFocused] = useState(false)
  // Raw string while typing — allows "0." mid-entry
  const [raw, setRaw] = useState(value === 0 ? '' : String(value))

  // Sync raw when value changes from outside (e.g. reset)
  useEffect(() => {
    if (!focused) setRaw(value === 0 ? '' : String(value))
  }, [value, focused])

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    let v = e.target.value
    // [BOEK-031] comma → dot for decimal — May 2026
    v = v.replace(',', '.')
    // Only allow valid number characters: digits, one dot, optional minus
    if (!/^-?\d*\.?\d*$/.test(v)) return
    setRaw(v)
    const parsed = parseFloat(v)
    if (!isNaN(parsed)) onChange(Math.max(min, parsed))
  }

  function handleBlur() {
    setFocused(false)
    // [BOEK-031] clean up on blur — remove leading zeros — May 2026
    const parsed = parseFloat(raw)
    if (isNaN(parsed) || parsed < min) {
      setRaw(min === 0 ? '' : String(min))
      onChange(min)
    } else {
      setRaw(String(parsed))
      onChange(parsed)
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    // [BOEK-031] comma key → insert dot — May 2026
    if (e.key === ',') {
      e.preventDefault()
      if (!raw.includes('.')) {
        const next = raw ? raw + '.' : '0.'
        setRaw(next)
      }
      return
    }
    // [BOEK-031] Enter → focus next input — May 2026
    if (e.key === 'Enter') {
      e.preventDefault()
      const form = e.currentTarget.closest('[data-form]') ?? document
      const focusable = Array.from(
        form.querySelectorAll<HTMLElement>('input, select')
      ).filter(el => !el.hasAttribute('disabled'))
      const idx = focusable.indexOf(e.currentTarget)
      if (idx >= 0 && idx < focusable.length - 1) focusable[idx + 1].focus()
      return
    }
    // [BOEK-031] ArrowUp/Down step by 1 whole number — May 2026
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault()
      const delta = e.key === 'ArrowUp' ? 1 : -1
      const current = parseFloat(raw) || 0
      const next = Math.max(min, Math.round(current) + delta)
      setRaw(String(next))
      onChange(next)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <label style={{ fontSize: 12, fontWeight: 500, color: hasError ? '#EA4335' : focused ? focusColor : '#5F6368' }}>{label}</label>
      <input
        type="text"
        inputMode="decimal"
        value={focused ? raw : (value === 0 ? '' : String(value))}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onFocus={() => { setFocused(true); setRaw(value === 0 ? '' : String(value)) }}
        onBlur={handleBlur}
        placeholder="0"
        style={{
          width: '100%', minHeight: 44,
          border: `${hasError || focused ? '2px' : '1px'} solid ${hasError ? '#EA4335' : focused ? focusColor : '#E0E0E0'}`,
          borderRadius: 8, padding: '0 12px',
          fontSize: 16, color: '#202124',
          backgroundColor: hasError ? '#FFF8F7' : 'white', outline: 'none',
          boxSizing: 'border-box', transition: 'border 0.1s ease',
          fontFamily: 'Roboto Mono, monospace',
        }}
      />
    </div>
  )
}

// ─── [DS] OutlinedInput — Material You Outlined Text Field ─────────────────────
// font-size: 16px mandatory to prevent iOS auto-zoom
// Enter key moves focus to next input
function OutlinedInput({
  value, onChange, onFocus, placeholder, label, type = 'text', required = false, focusColor, hasError = false,
}: {
  value: string | number
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  onFocus?: () => void
  placeholder?: string
  label: string
  type?: string
  required?: boolean
  focusColor: string
  hasError?: boolean
}) {
  const [focused, setFocused] = useState(false)

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.preventDefault()
      const form = e.currentTarget.closest('[data-form]') ?? document
      const focusable = Array.from(
        form.querySelectorAll<HTMLElement>('input, select, button, textarea')
      ).filter(el => !el.hasAttribute('disabled') && el.tabIndex !== -1)
      const idx = focusable.indexOf(e.currentTarget)
      if (idx >= 0 && idx < focusable.length - 1) focusable[idx + 1].focus()
    }
  }

  // [BOEK-031] border color priority: error > focused > default
  const borderColor = hasError ? '#EA4335' : focused ? focusColor : '#E0E0E0'
  const borderWidth = hasError || focused ? '2px' : '1px'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <label style={{ fontSize: 14, fontWeight: 500, color: hasError ? '#EA4335' : focused ? focusColor : '#5F6368' }}>
        {label}{required && <span style={{ color: '#EA4335', marginLeft: 2 }}>*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        onKeyDown={handleKeyDown}
        onFocus={() => { setFocused(true); onFocus?.() }}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        style={{
          width: '100%',
          minHeight: 48,
          border: `${borderWidth} solid ${borderColor}`,
          borderRadius: 8,
          padding: '0 16px',
          fontSize: 16,
          color: '#202124',
          backgroundColor: hasError ? '#FFF8F7' : 'white',
          outline: 'none',
          boxSizing: 'border-box',
          transition: 'border 0.1s ease',
          fontFamily: 'inherit',
        }}
      />
    </div>
  )
}

// ─── Component ─────────────────────────────────────────────────────────────────

function NewInvoicePageContent() {
  const router       = useRouter()
  const searchParams = useSearchParams()
  const supabase     = createClient()

  // Read query params at component level so useEffect doesn't depend on searchParams
  const typeParam           = searchParams.get('type') as InvoiceType | null
  const originalParam       = searchParams.get('original') ?? ''
  const offerteParam        = searchParams.get('from_offerte') ?? ''
  const replacesParam       = searchParams.get('replaces') ?? ''
  const replacesNumberParam = searchParams.get('replacesNumber') ?? ''
  // AI-generated params from ZzpDashboard
  const aiClientName    = searchParams.get('client_name') ?? ''
  const aiClientEmail   = searchParams.get('client_email') ?? ''
  // [BOEK-029] offerte→factuur params — all client fields
  const aiClientAddress = searchParams.get('client_address') ?? ''
  const aiClientPostal  = searchParams.get('client_postal_code') ?? ''
  const aiClientCity    = searchParams.get('client_city') ?? ''
  const aiClientBtw     = searchParams.get('client_btw_number') ?? ''
  const aiDescription   = searchParams.get('description') ?? ''
  const aiAmount        = parseFloat(searchParams.get('amount') ?? '0') || 0
  const aiBtwRate       = parseFloat(searchParams.get('btw_rate') ?? '21') || 21

  // ── Core state ──────────────────────────────────────────────────────────────
  const [profile, setProfile]         = useState<Profile | null>(null)
  // [BOEK-031] Navigation Strategy — parent + home via helper — May 2026
  const role: Role = (profile?.role === 'accountant' ? 'accountant' : 'zzper')
  const parentHref = useParentPath(role)
  const homeHref = useHomePath(role)
  const [invoiceNumber, setInvoiceNumber] = useState('')
  const [loading, setLoading]         = useState(false)
  // [BOEK-031] linesLoading — wait for DB lines before allowing submit — May 2026
  const [linesLoading, setLinesLoading] = useState(!!offerteParam)
  const [error, setError]             = useState('')
  // [BOEK-031] Field-level errors — shows red borders on specific fields — May 2026
  const [fieldErrors, setFieldErrors] = useState<{
    clientName?: boolean
    clientEmail?: boolean
    invoiceDate?: boolean
    dueDate?: boolean
    lines?: { description?: boolean; unit_price?: boolean; quantity?: boolean }[]
  }>({})

  function clearFieldError(field: string) {
    setFieldErrors(prev => ({ ...prev, [field]: false }))
  }

  // [BOEK-031] Invoice type — from_offerte always forces factuur — May 2026
  const [invoiceType, setInvoiceType] = useState<InvoiceType>(
    offerteParam
      ? 'factuur'  // coming from offerte → always factuur
      : typeParam && ['factuur', 'offerte', 'creditnota'].includes(typeParam)
        ? typeParam
        : 'factuur'
  )

  // ── Client autocomplete ──────────────────────────────────────────────────────
  const [clients, setClients]               = useState<Client[]>([])
  const [clientSearch, setClientSearch]     = useState(aiClientName)
  const [showDropdown, setShowDropdown]     = useState(false)
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null)
  const autocompleteRef                     = useRef<HTMLDivElement>(null)

  // ── Client fields ────────────────────────────────────────────────────────────
  const [clientName, setClientName]       = useState(aiClientName)
  const [clientEmail, setClientEmail]     = useState(aiClientEmail)
  // [BOEK-029] pre-fill from offerte params — May 2026
  const [clientAddress, setClientAddress] = useState(aiClientAddress)
  const [clientPostal, setClientPostal]   = useState(aiClientPostal)
  const [clientCity, setClientCity]       = useState(aiClientCity)
  const [clientBtw, setClientBtw]         = useState(aiClientBtw)

  // ── Dates ────────────────────────────────────────────────────────────────────
  const today = new Date().toISOString().split('T')[0]
  const [invoiceDate, setInvoiceDate] = useState(today)
  const [dueDate, setDueDate]         = useState('')

  // ── Lines — pre-filled from replace flow, offerte, or AI generation ──────────
  // [BOEK-029] from offerte: use total_ex_btw as unit_price so BTW calculates correctly
  const aiTotalExBtw = parseFloat(searchParams.get('total_ex_btw') ?? '0') || 0
  const aiTotalIncBtw = parseFloat(searchParams.get('total_inc_btw') ?? '0') || 0
  const offerteUnitPrice = aiTotalExBtw > 0 ? aiTotalExBtw : aiTotalIncBtw || aiAmount

  const [lines, setLines] = useState<InvoiceLine[]>(
    replacesNumberParam
      ? [{ description: `Vervangt factuur ${replacesNumberParam}`, quantity: 1, unit_price: 0, btw_rate: 21 }]
      : offerteParam
        ? [{ description: aiDescription || '', quantity: 1, unit_price: offerteUnitPrice, btw_rate: aiBtwRate }]
        : [{ description: aiDescription, quantity: 1, unit_price: aiAmount, btw_rate: aiBtwRate }]
  )

  // ── Credit flow ──────────────────────────────────────────────────────────────
  const [sentInvoices, setSentInvoices]       = useState<SentInvoice[]>([])
  const [originalInvoiceId, setOriginalInvoiceId] = useState(originalParam)
  const [creditReason, setCreditReason]       = useState('')
  const [loadingCredit, setLoadingCredit]     = useState(false)

  // ── Replace flow — read-only from URL, never mutated ─────────────────────────
  const replacesId     = replacesParam
  const replacesNumber = replacesNumberParam

  // ── Offerte convert confirm ───────────────────────────────────────────────────
  const [showConvertDialog, setShowConvertDialog] = useState(false)
  const [convertingOfferte, setConvertingOfferte] = useState(false)
  // offerte_id if we're converting an existing offerte — read-only from URL
  const offerteId = offerteParam

  // ─── Load ──────────────────────────────────────────────────────────────────

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      // Profile
      const { data: p } = await supabase.from('profiles').select('*').eq('id', user.id).single()
      if (p) setProfile(p)

      // Due date default +30 days
      const due = new Date(); due.setDate(due.getDate() + 30)
      setDueDate(due.toISOString().split('T')[0])

      // [BOEK-031] Invoice number — new format 001-2026 — May 2026
      // type determined by current invoiceType at load time (factuur default)
      const initType = offerteParam ? 'factuur'
        : typeParam === 'creditnota' ? 'creditnota'
        : typeParam === 'offerte' ? 'pro_forma'
        : 'factuur'
      // [BOEK-031] Draft = no number. Generated only on send. — May 2026
      // Pro forma is exception — needs preview number for UX.
      if (initType === 'pro_forma') {
        const num = await generateNumber(supabase, user.id, initType)
        setInvoiceNumber(num)
      } else {
        setInvoiceNumber('') // empty = "Concept" in UI
      }

      // Clients autocomplete
      const { data: cl } = await supabase
        .from('clients').select('*').eq('user_id', user.id).order('name')
      if (cl) setClients(cl)

      // Sent invoices for credit flow
      const { data: sent } = await supabase
        .from('invoices')
        .select('id, invoice_number, client_name, total_inc_btw')
        .eq('sender_id', user.id)
        .in('status', ['sent', 'paid', 'overdue'])
        .eq('invoice_type', 'factuur')
        .order('created_at', { ascending: false })
        .limit(50)
      if (sent) setSentInvoices(sent)

      // [BOEK-029] from_offerte: load original invoice_lines for accurate amounts
      if (offerteParam) {
        const { data: offLines } = await supabase
          .from('invoice_lines')
          .select('description, quantity, unit_price, btw_rate')
          .eq('invoice_id', offerteParam)
        if (offLines && offLines.length > 0) {
          setLines(offLines.map(l => ({
            description: l.description ?? '',
            quantity:    l.quantity    ?? 1,
            unit_price:  l.unit_price  ?? 0,
            btw_rate:    l.btw_rate    ?? 21,
          })))
        }
        // [BOEK-031] lines loaded from DB — allow submit — May 2026
        setLinesLoading(false)
      }
    }
    load()
  }, [router, supabase])

  // Close autocomplete on outside click
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (autocompleteRef.current && !autocompleteRef.current.contains(e.target as Node)) {
        setShowDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  // ─── Client autocomplete ───────────────────────────────────────────────────

  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    (c.email ?? '').toLowerCase().includes(clientSearch.toLowerCase())
  ).slice(0, 6)

  function selectClient(c: Client) {
    setSelectedClientId(c.id)
    setClientName(c.name)
    setClientEmail(c.email ?? '')
    setClientAddress(c.address ?? '')
    setClientPostal(c.postal_code ?? '')
    setClientCity(c.city ?? '')
    setClientBtw(c.btw_number ?? '')
    setClientSearch(c.name)
    setShowDropdown(false)
  }

  async function saveNewClient(userId: string) {
    if (!clientName || selectedClientId) return
    const { data } = await supabase.from('clients').insert({
      user_id: userId,
      name: clientName,
      email: clientEmail,
      address: clientAddress,
      postal_code: clientPostal,
      city: clientCity,
      btw_number: clientBtw,
    }).select().single()
    if (data) setSelectedClientId(data.id)
  }

  // ─── Lines ─────────────────────────────────────────────────────────────────

  function addLine() {
    setLines(prev => [...prev, { description: '', quantity: 1, unit_price: 0, btw_rate: 21 }])
  }

  function removeLine(i: number) {
    if (lines.length === 1) return
    setLines(prev => prev.filter((_, idx) => idx !== i))
  }

  function updateLine(i: number, field: keyof InvoiceLine, value: string | number | boolean) {
    setLines(prev => prev.map((l, idx) => idx === i ? { ...l, [field]: value } : l))
  }

  // [BOEK-031] AI translation per line — via API route (client-safe) — May 2026
  async function translateLine(i: number) {
    const line = lines[i]
    if (!line.description.trim()) return
    updateLine(i, 'translating', true)
    try {
      const res = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: line.description, sourceLanguage: 'auto' }),
      })
      if (res.ok) {
        const result = await res.json()
        if (result.translation) updateLine(i, 'description', result.translation)
      }
      // safe fallback — if fails, keep original
    } catch {
      // keep original
    } finally {
      updateLine(i, 'translating', false)
    }
  }

  // ─── Totals ────────────────────────────────────────────────────────────────

  // [BOEK-031] Credit: user enters positive — system saves negative
  const sign      = invoiceType === 'creditnota' ? -1 : 1
  const totalEx   = lines.reduce((s, l) => s + l.quantity * l.unit_price, 0)
  const btwAmount = lines.reduce((s, l) => s + l.quantity * l.unit_price * (l.btw_rate / 100), 0)
  const totalInc  = totalEx + btwAmount

  // [BOEK-031] computeTotals — always fresh from current lines state — May 2026
  // Used inside submit functions to avoid stale closure values
  function computeTotals(currentLines: InvoiceLine[], currentSign = 1) {
    const ex  = currentLines.reduce((s, l) => s + l.quantity * l.unit_price, 0)
    const btw = currentLines.reduce((s, l) => s + l.quantity * l.unit_price * (l.btw_rate / 100), 0)
    return {
      total_ex_btw:  currentSign * ex,
      btw_amount:    currentSign * btw,
      total_inc_btw: currentSign * (ex + btw),
    }
  }

  // BTW breakdown per rate
  const btwByRate: Record<number, number> = {}
  lines.forEach(l => {
    const rate = l.btw_rate
    btwByRate[rate] = (btwByRate[rate] ?? 0) + l.quantity * l.unit_price * (rate / 100)
  })

  // ─── Credit submit ─────────────────────────────────────────────────────────

  async function handleCredit() {
    if (!originalInvoiceId) { setError('Selecteer de originele factuur'); return }
    setLoadingCredit(true); setError('')
    try {
      const res = await fetch('/api/invoice/creditnota', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ original_invoice_id: originalInvoiceId, reason: creditReason }),
      })
      const result = await res.json()
      if (!res.ok) { setError(result.error || 'Mislukt'); return }
      // [BOEK-031] replace ipv push — Navigation Strategy — May 2026
      router.replace(result.creditnota_id ? `/dashboard/invoice/${result.creditnota_id}` : '/dashboard/facturen')
    } catch { setError('Onbekende fout') }
    finally { setLoadingCredit(false) }
  }

  // ─── Offerte → Factuur convert ─────────────────────────────────────────────

  async function handleConvertOfferte() {
    setConvertingOfferte(true); setError('')
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }

    // [BOEK-031] New format: 001-2026 — May 2026
    const newNum = await generateNumber(supabase, user.id, 'factuur')

    // [BOEK-031] Always compute fresh from current lines — May 2026
    const totals = computeTotals(lines)

    const { data: factuur, error: err } = await supabase.from('invoices').insert({
      sender_id: user.id,
      invoice_number: newNum,
      invoice_date: invoiceDate,
      due_date: dueDate,
      status: 'sent',
      invoice_type: 'factuur',
      direction: 'outgoing',
      ...totals,
      sent_to_accountant: false,
      source: 'created',
      client_name: clientName,
      client_email: clientEmail,
      client_address: clientAddress,
      client_postal_code: clientPostal,
      client_city: clientCity,
      client_btw_number: clientBtw,
    }).select().single()

    if (err || !factuur) { setError('Omzetten mislukt'); setConvertingOfferte(false); return }

    await supabase.from('invoice_lines').insert(
      lines.map(l => ({
        invoice_id: factuur.id,
        description: l.description,
        quantity: l.quantity,
        unit_price: l.unit_price,
        btw_rate: l.btw_rate,
        line_total: l.quantity * l.unit_price,
      }))
    )

    // Mark offerte as converted
    if (offerteId) {
      await supabase.from('invoices')
        .update({ status: 'archived' })
        .eq('id', offerteId)
    }

    setShowConvertDialog(false)
    // [BOEK-031] replace ipv push — Navigation Strategy — May 2026
    router.replace(`/dashboard/invoice/${factuur.id}`)
  }

  // ─── Main submit ───────────────────────────────────────────────────────────

  async function handleSubmit(mode: 'draft' | 'sent') {
    // [BOEK-031] wait for lines to load from DB before submitting — May 2026
    if (linesLoading) return
    // [BOEK-031] Validate all fields at once — show red borders — May 2026
    const errs: typeof fieldErrors = {}
    let hasAnyError = false

    if (!clientName) { errs.clientName = true; hasAnyError = true }
    if (!clientEmail) { errs.clientEmail = true; hasAnyError = true }
    if (!invoiceDate) { errs.invoiceDate = true; hasAnyError = true }
    if (!dueDate) { errs.dueDate = true; hasAnyError = true }

    const lineErrs = lines.map(l => ({
      description: !l.description.trim(),
      unit_price: l.unit_price <= 0,
      quantity: l.quantity <= 0,
    }))
    const hasLineError = lineErrs.some(l => l.description || l.unit_price || l.quantity)
    if (hasLineError) hasAnyError = true

    if (hasAnyError) {
      setFieldErrors({ ...errs, lines: lineErrs })
      setError('Vul de rood gemarkeerde velden in')
      // Scroll to first error
      setTimeout(() => {
        const firstRed = document.querySelector('[data-form] input[style*="#EA4335"], [data-form] input[style*="FFF8F7"]') as HTMLElement
        firstRed?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 50)
      return
    }

    setFieldErrors({})
    setError('')

    setLoading(true); setError('')
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }

    await saveNewClient(user.id)

    // [BOEK-031] Always compute fresh totals — avoid stale closure — May 2026
    const currentSign = invoiceType === 'creditnota' ? -1 : 1
    const freshTotals = computeTotals(lines, currentSign)

    // [BOEK-031] New numbering format: 001-2026 / CR-001-2026 / PF-001-2026 — May 2026
    let finalNumber = invoiceNumber
    if (invoiceType === 'offerte') {
      // Pro forma gets PF- number in DB but not shown in UI
      finalNumber = await generateNumber(supabase, user.id, 'pro_forma')
    } else if (mode === 'sent') {
      finalNumber = await generateNumber(supabase, user.id,
        invoiceType === 'creditnota' ? 'creditnota' : 'factuur'
      )
    } else {
      // [BOEK-031] draft = null. Number generated only on send. — May 2026
      finalNumber = ''
    }

    // DB invoice_type mapping
    const dbType = invoiceType === 'creditnota' ? 'creditnota'
                 : invoiceType === 'offerte' ? 'pro_forma'
                 : 'factuur'

    const { data: invoice, error: insertErr } = await supabase.from('invoices').insert({
      sender_id: user.id,
      invoice_number: finalNumber || null,
      invoice_date: invoiceDate,
      due_date: dueDate,
      status: mode === 'sent' ? 'sent' : 'draft',
      invoice_type: dbType,
      direction: 'outgoing',
      // [BOEK-031] credit: bedragen zijn negatief — gebruik freshTotals
      ...freshTotals,
      sent_to_accountant: false,
      source: 'created',
      client_name: clientName,
      client_email: clientEmail,
      client_address: clientAddress,
      client_postal_code: clientPostal,
      client_city: clientCity,
      client_btw_number: clientBtw,
      // [BOEK-031] creditnota is standalone — original_invoice_id = null always — May 2026
      original_invoice_id: invoiceType === 'creditnota' ? null : (replacesId || null),
    }).select().single()

    if (insertErr || !invoice) {
      setError('Aanmaken mislukt — probeer opnieuw')
      setLoading(false); return
    }

    await supabase.from('invoice_lines').insert(
      lines.map(l => ({
        invoice_id: invoice.id,
        description: l.description,
        quantity: sign * l.quantity,
        unit_price: l.unit_price,
        btw_rate: l.btw_rate,
        line_total: sign * l.quantity * l.unit_price,
      }))
    )

    // [BOEK-031] Replace flow — markeer de oude factuur
    if (replacesId && finalNumber) {
      await supabase.from('invoices')
        .update({ replaced_by_number: finalNumber, status: 'archived' })
        .eq('id', replacesId)
    }

    // [BOEK-031] from_offerte flow — archiveer de originele offerte — May 2026
    // Note: offerte_converted_to FK update via server only to avoid RLS 400
    if (offerteId) {
      await supabase.from('invoices')
        .update({ status: 'archived' })
        .eq('id', offerteId)
    }

    // [BOEK-031] Email verzenden — non-blocking, nooit crash bij fout — May 2026
    if (mode === 'sent' && clientEmail) {
      fetch('/api/invoice/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceId: invoice.id,
          clientEmail,
          clientName,
          invoiceNumber: finalNumber,
          totalInc: freshTotals.total_inc_btw,
          dueDate,
        }),
      }).catch(() => {}) // volledig non-blocking
    }

    // [BOEK-031] replace naar detail pagina — Navigation Strategy — May 2026
    router.replace(`/dashboard/invoice/${invoice.id}`)
  }

  // ─── Derived ───────────────────────────────────────────────────────────────

  const cfg = TYPE_CONFIG[invoiceType]
  const pageTitle =
    invoiceType === 'offerte' ? 'Nieuwe offerte' :
    invoiceType === 'creditnota'  ? 'Creditnota'     : 'Nieuwe factuur'

  // [BOEK-031] Number already in correct format: 001-2026 / CR-001-2026 / PF-001-2026
  const displayNumber =
    invoiceType === 'offerte' ? '—' :   // Pro forma: geen nummer in UI
    invoiceNumber || 'Concept'

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#F8F9FA', position: 'relative' }}>
      {/* [DS] Top color band behind sticky header */}
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 64, backgroundColor: 'rgba(255,255,255,0.92)', zIndex: 9 }} />

      {/* [DS] Sticky header — frosted glass Material You */}
      <div style={{ position: 'sticky', top: 0, zIndex: 10, backgroundColor: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(0,0,0,0.06)', padding: '12px 16px' }}>
        <div style={{ maxWidth: 600, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {/* [BOEK-031] Back — Link to parent /dashboard/facturen — Navigation Strategy — May 2026 */}
            <Link href={parentHref}
              style={{ width: 36, height: 36, borderRadius: 9999, border: 'none', backgroundColor: 'transparent', color: '#5F6368', cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background 0.1s', textDecoration: 'none' }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#E7E0EC')}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
            >←</Link>
            {/* [BOEK-031] Logo — always /dashboard for ZZP — Navigation Strategy — May 2026 */}
            <Link href={homeHref} style={{ textDecoration: 'none', marginRight: 4 }}>
              <span style={{ fontSize: 15, fontWeight: 700, color: '#1A73E8', letterSpacing: '-0.01em' }}>
                BoekBrug
              </span>
            </Link>
            <div>
              {/* [DS] Title — 16px/700 */}
              <h1 style={{ fontSize: 16, fontWeight: 700, color: '#202124', margin: 0, lineHeight: 1.2 }}>{pageTitle}</h1>
              {invoiceType !== 'offerte' && (
                <p style={{ fontSize: 11, color: '#9AA0A6', fontFamily: 'Roboto Mono, monospace', margin: '2px 0 0' }}>{displayNumber}</p>
              )}
            </div>
          </div>
          {invoiceType === 'offerte' && offerteId && (
            <button onClick={() => setShowConvertDialog(true)}
              style={{ fontSize: 13, fontWeight: 500, padding: '8px 16px', borderRadius: 9999, border: 'none', backgroundColor: '#1A73E8', color: 'white', cursor: 'pointer' }}>
              Omzetten naar factuur →
            </button>
          )}
        </div>
      </div>

      <div data-form style={{ maxWidth: 600, margin: '0 auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 8, paddingBottom: 'calc(160px + env(safe-area-inset-bottom))' }}>

        {/* [DS] Segmented Button — Material You, één geheel */}
        <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' }}>
          <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: '0 0 12px' }}>Type document</p>
          <div style={{ display: 'flex', borderRadius: 9999, border: '1px solid #E0E0E0', overflow: 'hidden', backgroundColor: '#F1F3F4' }}>
            {(Object.keys(TYPE_CONFIG) as InvoiceType[]).map((t, idx, arr) => {
              const c = TYPE_CONFIG[t]
              const active = invoiceType === t
              return (
                <button key={t} onClick={() => setInvoiceType(t)}
                  style={{
                    flex: 1,
                    padding: '10px 8px',
                    border: 'none',
                    borderLeft: idx > 0 ? '1px solid #E0E0E0' : 'none',
                    backgroundColor: active ? c.activeBg : 'transparent',
                    color: active ? c.activeColor : '#5F6368',
                    fontWeight: active ? 600 : 400,
                    fontSize: 14,
                    cursor: 'pointer',
                    transition: 'all 0.15s cubic-bezier(0.4,0,0.2,1)',
                    // [DS] pill radius alleen op uiteinden
                    borderRadius: idx === 0 ? '9999px 0 0 9999px' : idx === arr.length - 1 ? '0 9999px 9999px 0' : 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  }}
                >
                  {active && <span style={{ fontSize: 14 }}>✓</span>}
                  {c.label}
                </button>
              )
            })}
          </div>
        </div>


        {/* [DS] Credit banner — border-left 4px style */}
        {invoiceType === 'creditnota' && (
          <div style={{ backgroundColor: '#F9DEDC', borderLeft: '4px solid #EA4335', borderRadius: '0 12px 12px 0', padding: '12px 16px', display: 'flex', gap: 8, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 16, color: '#B3261E', flexShrink: 0 }}>↩</span>
            <p style={{ fontSize: 13, color: '#B3261E', margin: 0, lineHeight: 1.5 }}>
              <strong>Creditnota</strong> — bedragen worden automatisch negatief. Vul het formulier in zoals een gewone factuur.
            </p>
          </div>
        )}

        <>
            {replacesNumber && (
              <div style={{ backgroundColor: '#E8F0FE', borderLeft: '4px solid #1A73E8', borderRadius: '0 12px 12px 0', padding: '12px 16px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ color: '#1967D2', flexShrink: 0 }}>🔄</span>
                <p style={{ fontSize: 13, color: '#1967D2', margin: 0 }}>
                  <strong>Vervangende factuur</strong> voor <span style={{ fontFamily: 'Roboto Mono, monospace', fontWeight: 600 }}>{replacesNumber}</span>. De oude factuur wordt automatisch gearchiveerd.
                </p>
              </div>
            )}

            {/* [BOEK-031] from_offerte banner — May 2026 */}
            {offerteId && !replacesNumber && (
              <div style={{ backgroundColor: '#E6F4EA', borderLeft: '4px solid #34A853', borderRadius: '0 12px 12px 0', padding: '12px 16px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ color: '#137333', flexShrink: 0 }}>📄</span>
                <p style={{ fontSize: 13, color: '#137333', margin: 0 }}>
                  <strong>Factuur op basis van offerte</strong> — gegevens zijn vooringevuld. De offerte wordt gearchiveerd na opslaan.
                </p>
              </div>
            )}

            {invoiceType === 'offerte' && (
              <div style={{ backgroundColor: '#FEF7E0', borderLeft: '4px solid #FBBC04', borderRadius: '0 12px 12px 0', padding: '12px 16px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ color: '#EA8600', flexShrink: 0 }}>📋</span>
                <p style={{ fontSize: 13, color: '#EA8600', margin: 0 }}>
                  <strong>Offerte</strong> — geen factuurnummer. Gebruik "Omzetten naar factuur" als de klant akkoord gaat.
                </p>
              </div>
            )}

            {/* [DS] Van card */}
            {profile && (
              <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' }}>
                <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: '0 0 8px' }}>Van</p>
                <div style={{ borderTop: '0.5px solid #E0E0E0', paddingTop: 8, display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <p style={{ fontSize: 14, fontWeight: 600, color: '#202124', margin: 0 }}>{profile.company_name || profile.full_name}</p>
                  {profile.address && <p style={{ fontSize: 13, color: '#5F6368', margin: 0 }}>{profile.address}</p>}
                  {(profile.postal_code || profile.city) && <p style={{ fontSize: 13, color: '#5F6368', margin: 0 }}>{[profile.postal_code, profile.city].filter(Boolean).join(' ')}</p>}
                  <div style={{ display: 'flex', gap: 16, marginTop: 2 }}>
                    {profile.kvk_number && <p style={{ fontSize: 12, color: '#9AA0A6', margin: 0 }}>KVK: {profile.kvk_number}</p>}
                    {profile.btw_number && <p style={{ fontSize: 12, color: '#9AA0A6', margin: 0 }}>BTW: {profile.btw_number}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* [DS] Aan card */}
            <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: 0 }}>Aan</p>
              <div ref={autocompleteRef} style={{ position: 'relative' }}>
                <OutlinedInput value={clientSearch} onChange={e => { setClientSearch(e.target.value); setClientName(e.target.value); setSelectedClientId(null); setShowDropdown(true); clearFieldError('clientName') }} onFocus={() => setShowDropdown(true)} placeholder="Zoek of typ klantnaam..." focusColor={cfg.focusColor} label="Bedrijfsnaam" required hasError={!!fieldErrors.clientName} />
                {showDropdown && filteredClients.length > 0 && (
                  <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, backgroundColor: 'white', border: '1px solid #E0E0E0', borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.12)', zIndex: 20, overflow: 'hidden' }}>
                    {filteredClients.map(c => (
                      <button key={c.id} onClick={() => selectClient(c)} style={{ width: '100%', textAlign: 'left', padding: '10px 16px', border: 'none', borderBottom: '1px solid #F1F3F4', backgroundColor: 'white', cursor: 'pointer', display: 'block' }} onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#F8F9FA')} onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'white')}>
                        <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: 0 }}>{c.name}</p>
                        {c.email && <p style={{ fontSize: 12, color: '#5F6368', margin: '2px 0 0' }}>{c.email}</p>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <OutlinedInput value={clientEmail} onChange={e => { setClientEmail(e.target.value); clearFieldError('clientEmail') }} placeholder="klant@bedrijf.nl" label="E-mailadres" type="email" required focusColor={cfg.focusColor} hasError={!!fieldErrors.clientEmail} />
              <OutlinedInput value={clientAddress} onChange={e => setClientAddress(e.target.value)} placeholder="Straatnaam 1" label="Adres" focusColor={cfg.focusColor} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <OutlinedInput value={clientPostal} onChange={e => setClientPostal(e.target.value)} placeholder="1234 AB" label="Postcode" focusColor={cfg.focusColor} />
                <OutlinedInput value={clientCity} onChange={e => setClientCity(e.target.value)} placeholder="Amsterdam" label="Stad" focusColor={cfg.focusColor} />
              </div>
              <OutlinedInput value={clientBtw} onChange={e => setClientBtw(e.target.value)} placeholder="NL123456789B01" label="BTW-nummer klant" focusColor={cfg.focusColor} />
            </div>

            {/* [DS] Datums card */}
            <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: 0 }}>Datums</p>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <OutlinedInput value={invoiceDate} onChange={e => { setInvoiceDate(e.target.value); clearFieldError('invoiceDate') }} label={invoiceType === 'offerte' ? 'Offertedatum *' : 'Factuurdatum *'} type="date" focusColor={cfg.focusColor} hasError={!!fieldErrors.invoiceDate} />
                <OutlinedInput value={dueDate} onChange={e => { setDueDate(e.target.value); clearFieldError('dueDate') }} label={invoiceType === 'offerte' ? 'Geldig tot *' : 'Vervaldatum *'} type="date" focusColor={cfg.focusColor} hasError={!!fieldErrors.dueDate} />
              </div>
            </div>

            {/* [DS] Factuurregels card */}
            <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: 0 }}>{invoiceType === 'offerte' ? 'Offerteregels' : 'Factuurregels'}</p>
              <p style={{ fontSize: 12, color: '#9AA0A6', margin: '-4px 0 0' }}>Schrijf in uw eigen taal — druk op <strong>Vertaal</strong> voor professioneel Nederlands</p>

              {lines.map((line, i) => (
                <div key={i} style={{ backgroundColor: '#F8F9FA', borderRadius: 12, padding: 12, display: 'flex', flexDirection: 'column', gap: 8, position: 'relative' }}>
                  {lines.length > 1 && (
                    <button onClick={() => removeLine(i)} style={{ position: 'absolute', top: 8, right: 8, width: 24, height: 24, borderRadius: 9999, border: 'none', backgroundColor: 'transparent', color: '#9AA0A6', cursor: 'pointer', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }} onMouseEnter={e => (e.currentTarget.style.color = '#EA4335')} onMouseLeave={e => (e.currentTarget.style.color = '#9AA0A6')}>×</button>
                  )}
                  <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                    <div style={{ flex: 1 }}>
                      <OutlinedInput value={line.description} onChange={e => { updateLine(i, 'description', e.target.value); setFieldErrors(prev => { const l = [...(prev.lines ?? [])]; if (l[i]) l[i] = { ...l[i], description: false }; return { ...prev, lines: l } }) }} placeholder="Omschrijving dienst" label="Omschrijving" focusColor={cfg.focusColor} hasError={!!fieldErrors.lines?.[i]?.description} />
                    </div>
                    <button onClick={() => translateLine(i)} disabled={line.translating} style={{ flexShrink: 0, fontSize: 12, fontWeight: 500, padding: '10px 12px', borderRadius: 9999, border: 'none', backgroundColor: line.translating ? '#F1F3F4' : cfg.activeBg, color: line.translating ? '#9AA0A6' : cfg.activeColor, cursor: line.translating ? 'not-allowed' : 'pointer', whiteSpace: 'nowrap', marginBottom: 1 }}>
                      {line.translating ? '...' : 'Vertaal'}
                    </button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
                    {/* [BOEK-031] LineInput: no leading zero, comma=dot, step=1, Enter→next — May 2026 */}
                    <LineInput label="Aantal" value={line.quantity} min={0.01} focusColor={cfg.focusColor} hasError={!!fieldErrors.lines?.[i]?.quantity} onChange={v => { updateLine(i, 'quantity', v); setFieldErrors(prev => { const l = [...(prev.lines ?? [])]; if (l[i]) l[i] = { ...l[i], quantity: false }; return { ...prev, lines: l } }) }} />
                    <LineInput label="Prijs (€)" value={line.unit_price} min={0} focusColor={cfg.focusColor} hasError={!!fieldErrors.lines?.[i]?.unit_price} onChange={v => { updateLine(i, 'unit_price', v); setFieldErrors(prev => { const l = [...(prev.lines ?? [])]; if (l[i]) l[i] = { ...l[i], unit_price: false }; return { ...prev, lines: l } }) }} />
                    <div>
                      <label style={{ fontSize: 12, fontWeight: 500, color: '#5F6368', display: 'block', marginBottom: 4 }}>BTW %</label>
                      <select value={line.btw_rate} onChange={e => updateLine(i, 'btw_rate', parseFloat(e.target.value))} style={{ width: '100%', minHeight: 44, border: '1px solid #E0E0E0', borderRadius: 8, padding: '0 12px', fontSize: 16, backgroundColor: 'white', outline: 'none', boxSizing: 'border-box', appearance: 'none', cursor: 'pointer' }} onFocus={e => { e.currentTarget.style.borderColor = cfg.focusColor; e.currentTarget.style.borderWidth = '2px' }} onBlur={e => { e.currentTarget.style.borderColor = '#E0E0E0'; e.currentTarget.style.borderWidth = '1px' }}>
                        <option value={21}>21%</option>
                        <option value={9}>9%</option>
                        <option value={0}>0%</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#9AA0A6' }}>
                    <span>Totaal</span>
                    <span style={{ fontWeight: 600, color: '#202124', fontFamily: 'Roboto Mono, monospace' }}>{NL_NUMBER.format(line.quantity * line.unit_price)}</span>
                  </div>
                </div>
              ))}

              <button onClick={addLine} style={{ alignSelf: 'flex-start', fontSize: 14, fontWeight: 500, color: '#1A73E8', background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0' }}>
                + Regel toevoegen
              </button>
            </div>

            {/* [DS] Totalen */}
            <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' }}>
              <div style={{ maxWidth: 280, marginLeft: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#5F6368' }}>
                  <span>Subtotaal excl. BTW</span>
                  <span style={{ fontFamily: 'Roboto Mono, monospace' }}>{NL_NUMBER.format(sign * totalEx)}</span>
                </div>
                {Object.entries(btwByRate).filter(([, v]) => v > 0).map(([rate, val]) => (
                  <div key={rate} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#5F6368' }}>
                    <span>BTW {rate}%</span>
                    <span style={{ fontFamily: 'Roboto Mono, monospace' }}>{NL_NUMBER.format(sign * val)}</span>
                  </div>
                ))}
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16, fontWeight: 700, color: sign === -1 ? '#B3261E' : '#202124', paddingTop: 8, borderTop: '1px solid #F1F3F4' }}>
                  <span>Totaal incl. BTW</span>
                  <span style={{ fontFamily: 'Roboto Mono, monospace' }}>{NL_NUMBER.format(sign * totalInc)}</span>
                </div>
              </div>
            </div>

            {/* [DS] Betalingsinformatie */}
            {profile?.iban && invoiceType !== ('creditnota' as InvoiceType) && (
              <div style={{ backgroundColor: 'white', borderRadius: 16, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' }}>
                <p style={{ fontSize: 14, fontWeight: 500, color: '#202124', margin: '0 0 12px' }}>Betalingsinformatie</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {([['Op naam van', profile.company_name || profile.full_name], ['IBAN', profile.iban], ['Vervaldatum', new Intl.DateTimeFormat('nl-NL').format(new Date(dueDate || today))], ...(invoiceNumber ? [['Betalingskenmerk', invoiceNumber]] : [])] as [string,string][]).map(([label, value]) => (
                    <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 14, color: '#5F6368', lineHeight: 1.8 }}>{label}</span>
                      <span style={{ fontSize: label === 'IBAN' ? 13 : 14, fontWeight: 500, color: '#202124', fontFamily: label === 'IBAN' ? 'Roboto Mono, monospace' : 'inherit', maxWidth: '55%', textAlign: 'right' }}>{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {error && (
              <div style={{ backgroundColor: '#F9DEDC', borderLeft: '4px solid #EA4335', borderRadius: '0 12px 12px 0', padding: '12px 16px' }}>
                <p style={{ fontSize: 14, color: '#B3261E', margin: 0 }}>{error}</p>
              </div>
            )}

            {/* [DS] Fixed bottom bar — safe area — full-width pill — 48px min */}
            <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(20px)', borderTop: '1px solid rgba(0,0,0,0.06)', padding: '12px 16px', paddingBottom: 'calc(12px + env(safe-area-inset-bottom))', zIndex: 10 }}>
              <div style={{ maxWidth: 600, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
                <button onClick={() => handleSubmit('sent')} disabled={loading || linesLoading} style={{ width: '100%', minHeight: 48, borderRadius: 9999, border: 'none', backgroundColor: loading || linesLoading ? '#9AA0A6' : cfg.primaryBtn, color: 'white', fontSize: 16, fontWeight: 600, cursor: loading || linesLoading ? 'not-allowed' : 'pointer', transition: 'all 0.15s cubic-bezier(0.4,0,0.2,1)' }}>
                  {linesLoading ? 'Laden...' : loading ? 'Bezig...' : invoiceType === 'factuur' ? '✉ Opslaan en versturen' : invoiceType === 'offerte' ? '📋 Versturen naar klant' : '↩ Versturen'}
                </button>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => handleSubmit('draft')} disabled={loading} style={{ flex: 1, minHeight: 48, borderRadius: 9999, border: 'none', backgroundColor: cfg.activeBg, color: cfg.activeColor, fontSize: 14, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer', transition: 'all 0.15s cubic-bezier(0.4,0,0.2,1)' }}>
                    {invoiceType === 'factuur' ? 'Opslaan als concept' : 'Opslaan'}
                  </button>
                  {/* [BOEK-031] Annuleren — Link to parent — Navigation Strategy — May 2026 */}
                  <Link href={parentHref}
                    style={{ minHeight: 48, padding: '0 20px', borderRadius: 9999, border: 'none', backgroundColor: 'transparent', color: '#5F6368', fontSize: 14, fontWeight: 500, cursor: 'pointer', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                    Annuleren
                  </Link>
                </div>
              </div>
            </div>
          </>
      </div>

      {/* [DS] Offerte → Factuur convert dialog */}
      {showConvertDialog && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 50, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', padding: '0 16px 24px', backgroundColor: 'rgba(0,0,0,0.4)' }}>
          <div style={{ backgroundColor: 'white', borderRadius: 24, padding: 24, width: '100%', maxWidth: 480, boxShadow: '0 4px 24px rgba(0,0,0,0.2)', display: 'flex', flexDirection: 'column', gap: 16 }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, color: '#202124', margin: 0 }}>Omzetten naar factuur</h2>
            <p style={{ fontSize: 14, color: '#5F6368', lineHeight: 1.6, margin: 0 }}>
              Controleer de gegevens voor het aanmaken van de factuur. Een nieuw factuurnummer wordt automatisch toegewezen. De offerte wordt gearchiveerd.
            </p>
            <p style={{ fontSize: 14, fontWeight: 600, color: '#202124', margin: 0 }}>Weet u het zeker?</p>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={handleConvertOfferte} disabled={convertingOfferte}
                style={{ flex: 1, minHeight: 48, borderRadius: 9999, border: 'none', backgroundColor: '#1A73E8', color: 'white', fontSize: 16, fontWeight: 600, cursor: convertingOfferte ? 'not-allowed' : 'pointer' }}>
                {convertingOfferte ? 'Bezig...' : 'Ja, maak factuur aan'}
              </button>
              <button onClick={() => setShowConvertDialog(false)}
                style={{ flex: 1, minHeight: 48, borderRadius: 9999, border: 'none', backgroundColor: '#F1F3F4', color: '#5F6368', fontSize: 14, fontWeight: 500, cursor: 'pointer' }}>
                Annuleren
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

export default function NewInvoicePage() {
  return (
    <Suspense>
      <NewInvoicePageContent />
    </Suspense>
  )
}